package com.createchance.doorgod.util;

/**
 * Protect type.
 */

public class LockTypeUtil {
    public static final int TYPE_PATTERN = 100;
    public static final int TYPE_PIN = 101;
}
