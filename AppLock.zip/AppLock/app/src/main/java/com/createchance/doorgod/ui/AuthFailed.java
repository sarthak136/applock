package com.createchance.doorgod.ui;

/**
 * Created by gaochao on 25/07/2017.
 */

public interface AuthFailed {
    void onFailed();
}
