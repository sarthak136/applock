package com.createchance.doorgod.util;

/**
 * Fingerprint Auth Request.
 */

public class FingerprintAuthRequest {
}
