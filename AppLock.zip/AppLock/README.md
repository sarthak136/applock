# DoorGod: An app locker to make your app available to yourself only.
 It is opensource and free by Apache Licence.
 
 Run it on android 5.0 or above.(API level >= 21) please.
